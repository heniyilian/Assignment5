package iss.java.mail;

import java.io.IOException;
import java.util.Properties;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class MailService2014301060003 implements IMailService
{
	/**
	 * �û���
	 */
	private final String userName="fdsafdas";
	/**
	 * ����
	 */
	private final String password="ewrewfdsaf";
	/**
	 * smtp������ַ
	 */
	private final String smtpHostName="smtp.163.com";
	/**
	 * imap������ַ
	 */
	private final String imapHostName="imap.163.com"; 
	/**
	 * ���͵�Properties
	 */
	private Properties sendProps;
	/**
	 * ���յ�Properties
	 */
	private Properties recieveProps;
	
	/**
	 * �ʼ���������¼��֤
	 */
	private MailAuthenticator mailAuthenticator;
	
	/**
	 * ��������session
	 */
	private Session sendSession;
	/**
	 * ��������session
	 */
	private Session RecieveSession;

	/* ���� Javadoc��
	 * @see iss.java.mail.IMailService#connect()
	 */
	@Override
	public void connect() throws MessagingException
	{
		mailAuthenticator=new MailAuthenticator(userName,password);
		
		sendProps=System.getProperties();
		sendProps.put("mail.smtp.auth", "true");
		sendProps.put("mail.smtp.host", smtpHostName);
		sendSession=Session.getInstance(sendProps,mailAuthenticator);
		
		recieveProps=System.getProperties();
		recieveProps.put("mail.store.protocol", "imap");
		recieveProps.put("mail.iamp.host", imapHostName);
		RecieveSession=Session.getInstance(recieveProps,mailAuthenticator);
	}

	/* ���� Javadoc��
	 * @see iss.java.mail.IMailService#send(java.lang.String, java.lang.String, java.lang.Object)
	 */
	@Override
	public void send(String recipient, String subject, Object content) throws MessagingException
	{
		final MimeMessage message=new MimeMessage(sendSession);
		message.setFrom(new InternetAddress(mailAuthenticator.getUsername()));
		message.setRecipient(MimeMessage.RecipientType.TO,new InternetAddress(recipient));
		message.setSubject(subject);
		message.setContent(content.toString(), "text/html;charset=utf-8");	
		Transport.send(message);
	}

	/* ���� Javadoc��
	 * @see iss.java.mail.IMailService#listen()
	 */
	@Override
	public boolean listen() throws MessagingException
	{
		Store store=RecieveSession.getStore();
		store.connect(imapHostName,userName,password);
		Folder folder=store.getFolder("inbox");
		folder.open(Folder.READ_ONLY);
		
		if(folder.getNewMessageCount()>0)
		{
			folder.close(false);
			store.close();	
			return true;
		}
		folder.close(false);
		store.close();		
		return false;
	}

	/* ���� Javadoc��
	 * @see iss.java.mail.IMailService#getReplyMessageContent(java.lang.String, java.lang.String)
	 */
	@Override
	public String getReplyMessageContent(String sender, String subject) throws MessagingException, IOException
	{
		String content = "";
		Store store=RecieveSession.getStore();
		store.connect(imapHostName,userName,password);
		Folder folder=store.getFolder("inbox");
		folder.open(Folder.READ_ONLY);
		for (int i = folder.getMessages().length; i > 0; i--) {
			Message message=folder.getMessage(i);
			// HomeworkLoader�����������subject�������ð����ȫ�ǵ�
			// ���Զ��ظ��ʼ���������ð���ǰ�ǵ�
			if (message.getSubject().toString().contains("2014301060003")) {
				content+="�ظ������⣺"+message.getSubject()+"\n"; 
				content+="�ظ��ķ����˵�ַ��:" + sender + "\n";
				content+="�ظ��������ǣ�"+message.getContent().toString()+"\n";
				break;
			}
			if (i == 1) content += "no right reply got";
		}
		folder.close(false);
		store.close();
		return content;
	}
}

